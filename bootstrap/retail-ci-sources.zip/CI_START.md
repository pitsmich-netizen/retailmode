# Retail Mode GitHub CI starter source bundle

Projects: `android/retail-dpc` (0.10.2-ci), `android/retail-helper` (0.2.9).
These are test-only Android Studio source files, not production-ready. No credentials or Wi-Fi passwords are included.

This archive should be placed in the public repo as `bootstrap/retail-ci-sources.zip` exactly once. A GitHub Actions workflow can unpack and commit the sources, compile both apps with the same test signing key, pin the Helper checksum, publish under immutable RAW URLs and automatically create a test prerelease.

Signing note: without `RETAIL_CI_DEBUG_KEYSTORE_B64` secret the GitHub runner will create a new debug signing identity; installs are for freshly wiped test devices only and are not compatible with earlier debug-signed apps. For continuity, provide the same Android Studio debug.keystore using an Actions secret. Never commit private keystores or passwords.
